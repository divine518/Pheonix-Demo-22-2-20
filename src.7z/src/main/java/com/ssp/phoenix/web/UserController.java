package com.ssp.phoenix.web;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ssp.phoenix.model.EventDetails;
import com.ssp.phoenix.model.Users;
import com.ssp.phoenix.repository.EventDetailsRepository;
import com.ssp.phoenix.service.UserService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService userService;
	@Autowired
	EventDetailsRepository eventRepository;
	
//	@GetMapping("/insertOrderDetails")
//	public Map<String, String> insertOrderDetails(String userName, String password) {
//		System.out.println("userId**login***" + userName + password);
//		Map<String, String> response = new HashMap<String, String>();
//		response.put("response", userService.login(userName, password));
//		return response;
	

	@GetMapping("/login")
	public Map<String, String> login(String userName, String password) {
		System.out.println("userId**login***" + userName + password);
		Map<String, String> response = new HashMap<String, String>();
		response.put("response", userService.login(userName, password));
		return response;
	}
	
	@PostMapping("/eventUpload")
	public Map<String, Object> eventUpload(@RequestParam MultipartFile file, String venue, String description, String eventDateinString, String title) {
		Map<String, Object> response = new HashMap<String, Object>();
		System.out.println("userId**login***" +  file +"--------"+eventDateinString);
		EventDetails eventDetails =  new EventDetails();
		try {
//		eventDetails.setDescription(description);
//		eventDetails.setTitle(title);
//		eventDetails.setVenue(venue);
//		eventDetails.setPic(file.getBytes());
		SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd" );  // United States style of format.
		java.util.Date myDate = format.parse( eventDateinString);  
		
		//java.util.Date myDate = new java.util.Date(eventDateinString);
		java.sql.Date eventDate = new java.sql.Date(myDate.getTime());
		//eventDetails.setEventDate(eventDate);
		eventDetails = eventRepository.findMaxId();
		int maxId = 1;
		if(StringUtils.isEmpty(eventDetails)) {
			maxId= 1;
		} else {
			maxId = eventDetails.getEvent_id();
			System.out.println("before-----"+maxId);
			maxId = maxId + 1;
		}
		System.out.println(maxId);
		//eventDetails.setEvent_id(maxId);
		//eventForm.setPic(file.getBytes());
		EventDetails img = new EventDetails( maxId,"wipro",eventDate,description,venue,title,file.getBytes());
		System.out.println(img);
		eventRepository.saveAndFlush(img);
		response.put("message", "success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			response.put("message", "failure");
			e.printStackTrace();
		}
		return response;
	}
	
	@GetMapping("/fetchEventDetails")
	public Map<String, Object> fetchEventDetails() {
		Map<String, Object> response = new HashMap<String, Object>();
		long millis=System.currentTimeMillis();  
		java.sql.Date date=new java.sql.Date(millis);  
		System.out.println(date);  
		try {
		//final List<EventDetails> savedImage = eventRepository.findAll();
	    Collection<EventDetails> savedImage = eventRepository.findByEventDate(date.toString());
			
		response.put("pic", savedImage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}

	@GetMapping("/userIdVarification")
	public String userIdVarification(String userId) {
		return userService.userIdVarification(userId);
	}

	@GetMapping("/registration")
	public Map<String, String> signup(@ModelAttribute Users users) {
		String decodeBloodGroup = URLDecoder.decode(users.getBloodGroup());
		users.setBloodGroup(decodeBloodGroup);
		System.out.println("users**signup**" + users);
		Map<String, String> response = new HashMap<String, String>();
		String validUserCheck = userIdVarification(users.getUser_id());
		if(validUserCheck.equalsIgnoreCase("Success")) {
			response.put("message", userService.signup(users));
		} else {
			response.put("message", "failure");
		}
		
		return response;
	}

	//@GetMapping("/delete")
	public String delete(String userId) {
		System.out.println("users**delete**" + userId);
		return userService.delete(userId);
	}

	@GetMapping("/update")
	public Map<String, String> update(@ModelAttribute Users user,String userAction) {
		//Users usersdemo = new Users("divine12", "divine", "divine@gmail.com", "a", "m", "a", "true", "a", "divine");
		System.out.println("users**update**" + user +"********"+userAction);
		Map<String, String> response = new HashMap<String, String>();
		String decodeBloodGroup = URLDecoder.decode(user.getBloodGroup());
		user.setBloodGroup(decodeBloodGroup);
		if(!StringUtils.isEmpty(userAction) && userAction.equals("Delete")) {
			String msg = delete(user.getUser_id());
			response.put("message", msg);
		} else if(!StringUtils.isEmpty(userAction) && userAction.equals("Update")){
			String msg = userService.update(user);
			System.out.println("msg"+msg);
			response.put("message", msg);
		}
		return response;
	}

	@GetMapping("/getUserDetails")
	public Users getUserDetails(String userId) {
		System.out.println("users**update**" + userId);
		return userService.getUserDetailsByID(userId);
	}

	@GetMapping("/getAllUser")
	public Collection<Users> getAllUser() {
		return userService.getAllUser();
	}
	
	@GetMapping("/getBloodFinderDetails")
	public Collection<Users> getBloodFinderDetails(@ModelAttribute Users users) {
		//Users usersdemo = new Users("divine12", "divine", "divine@gmail.com", "a", "m", "a", "true", "a", "divine");
		//userService.insertBloodFinderHistoryTbl(name, bloodGroup, mobileNumber, note, address);
		//Users usersdemo = new Users();
		//usersdemo.setBloodGroup("A-");
		//usersdemo.setArea("Chandigarh");
		//usersdemo.setState("Punjab");
		String decodeBloodGroup = URLDecoder.decode(users.getBloodGroup());
		users.setBloodGroup(decodeBloodGroup);
		System.out.println(users);
		return userService.getBloodFinderDetails(users);
	}
}
