package com.ssp.phoenix.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.ssp.phoenix.model.LoggedInUserDetails;
import com.ssp.phoenix.model.Users;
import com.ssp.phoenix.repository.UsersRepository;

@Service
public class UserService {

	@Autowired
	UsersRepository userRepository;

	public String login(String userId, String password) {
		try {
			Users users = getUserDetailsByID(userId);
			if (!StringUtils.isEmpty(users)) {
				if (!StringUtils.isEmpty(password) && password.equals(users.getPassword())) {
					LoggedInUserDetails.userID = userId;
					//LoggedInUserDetails.isAdmin = users.getIsAdmin();
					System.out.println("static data" + LoggedInUserDetails.userID + LoggedInUserDetails.isAdmin);
					return "success";
				} else {
					return "failure";
				}
			}
		} catch (Exception e) {
			System.out.println("error in login****" + e);
		}
		return "failure";
	}

	public String userIdVarification(String userId) {
		Users usersInDB = getUserDetailsByID(userId);
		if (!StringUtils.isEmpty(usersInDB) && usersInDB.getUser_id().equals(userId)) {
			return "User Id is already exists, Please Signup with new ID";
		} else {
			return "Success";
		}
	}

	public String signup(Users users) {
		try {
			userRepository.save(users);
		} catch (Exception e) {
			System.out.println("error in signup" + e);
			return "failure";
		}
		return "success";
	}

	public Users getUserDetailsByID(String userId) {
		Users users = null;
		try {
			users = userRepository.findByUser_id(userId);
		} catch (Exception e) {
			System.out.println("error in getUserDetailsByID" + e);
		}
		return users;
	}

	public String delete(String userId) {
		try {
			userRepository.deleteByUser_id(userId);
		} catch (Exception e) {
			System.out.println("error in delete" + e);
			return "failure";
		}
		return "success";
	}

	public String update(Users users) {
		try {
			userRepository.updateUser(users.getMobileNumber(), users.getBloodGroup(), users.getEmailId(),
					users.getAge(), users.getPassword(), users.getArea(), users.getState(),users.getName(), users.getUser_id());
		} catch (Exception e) {
			System.out.println("error in update" + e);
			return "failure";
		}
		return "success";
	}
	
	public Collection<Users> getAllUser() {
		return userRepository.findAll();
	}
	
	public Collection<Users> getBloodFinderDetails(Users users) {
		if(StringUtils.isEmpty(users.getArea()) && StringUtils.isEmpty(users.getState())){
			return userRepository.getBloodFinderByBG(users.getBloodGroup());
		} else if(!StringUtils.isEmpty(users.getArea()) && StringUtils.isEmpty(users.getState())) {
			return userRepository.getBloodFinderByArea(users.getBloodGroup(),users.getArea());
		} else if(StringUtils.isEmpty(users.getArea()) && !StringUtils.isEmpty(users.getState())) {
			return userRepository.getBloodFinderByState(users.getBloodGroup(),users.getState());
		} else {
			return userRepository.getBloodFinderUsers(users.getBloodGroup(),users.getState(), users.getArea());
		}
	}
	
	public void insertBloodFinderHistoryTbl(String name, String bloodGroup,
			String mobileNumber,String note, String address) {
		userRepository.insertBloodFinderHistoryTbl(name, bloodGroup, mobileNumber, note, address);
	}
}
