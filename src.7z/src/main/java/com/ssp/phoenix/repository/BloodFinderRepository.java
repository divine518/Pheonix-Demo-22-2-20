/*
 * package com.ssp.phoenix.repository;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.ssp.phoenix.model.BloodFinderHistory;
 * 
 * public interface BloodFinderRepository extends
 * JpaRepository<BloodFinderHistory, Long>{
 * 
 * }
 */