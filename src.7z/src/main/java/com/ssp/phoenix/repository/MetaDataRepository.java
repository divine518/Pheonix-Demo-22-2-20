/*
 * package com.ssp.phoenix.repository;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.ssp.phoenix.model.MetaData;
 * 
 * public interface MetaDataRepository extends JpaRepository<MetaData, Long>{
 * 
 * }
 */