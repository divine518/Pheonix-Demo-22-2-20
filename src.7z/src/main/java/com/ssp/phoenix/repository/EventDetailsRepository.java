package com.ssp.phoenix.repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ssp.phoenix.model.EventDetails;
@Repository
public interface EventDetailsRepository extends JpaRepository<EventDetails, Long>{

	@Modifying
	@Transactional
	@Query(value = "select * from EVENT_DETAILS u where u.EVENT_DATE ", nativeQuery = true)
	Collection<EventDetails> fetchEventDetails();
	
	@Modifying
	@Transactional
	@Query(value = "SELECT * FROM EVENT_DETAILS WHERE event_date >= to_date(:eventDate,'YYYY-MM-DD')", nativeQuery = true)
	Collection<EventDetails> findByEventDate(@Param("eventDate") String eventDate);
	
	@Transactional
	EventDetails findMaxId();
}
