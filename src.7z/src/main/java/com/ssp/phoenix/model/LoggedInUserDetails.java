package com.ssp.phoenix.model;

public class LoggedInUserDetails {

	public static String userID;
	public static String isAdmin;
}
