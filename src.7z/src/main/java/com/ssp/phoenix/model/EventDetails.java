package com.ssp.phoenix.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "EVENT_DETAILS")
@NamedNativeQuery(name = "EventDetails.findMaxId", query = "select * from (select * from EVENT_DETAILS order by event_id desc)where rownum=1", resultClass = EventDetails.class)
public class EventDetails {

	private int event_id;
	private String organiserName;
	private Date eventDate;
	private String eventDateinString;
	private String description;
	private String venue;
	private String title;
    private byte[] pic;

	
	public EventDetails() {
		
	}
	
	public EventDetails(int event_id, String organiserName, Date eventDate, String description, String venue,
			String title,  byte[] pic) {
		super();
		this.event_id = event_id;
		this.organiserName = organiserName;
		this.eventDate = eventDate;
		this.description = description;
		this.venue = venue;
		this.title = title;
		this.pic = pic;
	}
	@Transient
	public String getEventDateinString() {
		return eventDateinString;
	}

	public void setEventDateinString(String eventDateinString) {
		this.eventDateinString = eventDateinString;
	}
	@Column(name = "FOR_CAUSE", nullable = true)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EVENT_ID", nullable = true)
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	@Column(name = "ORGANISER_NAME", nullable = true)
	public String getOrganiserName() {
		return organiserName;
	}
	public void setOrganiserName(String organiserName) {
		this.organiserName = organiserName;
	}
	@Column(name = "EVENT_DATE", nullable = true)
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	@Column(name = "DESCRIPTION", nullable = true)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Column(name = "VENUE", nullable = true)
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
//	@Column(name = "FOR_CAUSE", nullable = true)
//	public String getForCause() {
//		return title;
//	}
//	public void setForCause(String forCause) {
//		this.title = forCause;
//	}
	@Column(name = "PIC_BYTE_CODE", nullable = true)
	public byte[] getPic() {
		return pic;
	}

	public void setPic(byte[] pic) {
		this.pic = pic;
	}

	@Override
	public String toString() {
		return "EventDetails [event_id=" + event_id + ", organiserName=" + organiserName + ", eventDate=" + eventDate
				+ ", description=" + description + ", venue=" + venue + ", forCause=" + title + "]";
	}
	
}
